
<?php include 'includes/connection.php';?>
<?php 
require 'includes/login.inc.php';
?>
<?php 
require 'includes/signup.inc.php';
?>
<html>
<head>
	<title>STUDENT||DISCUSSION||FORUM||INDEXPAGE</title>

	<!--Custom CSS-->
	<link rel="stylesheet" type="text/css" href="css/global.css">
	<!--Bootstrap CSS-->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

    <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <!--Script-->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body background="images/body.jpg">
  <img src="images/forumlogo.png">
	<!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">



            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="home.php"></a>
            </div>
            <div class="navbar-header">
                <a class="navbar-brand" >STUDENT DISCUSSION FORUM</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            	<!--
                <ul class="nav navbar-nav navbar-left">
                    <li><a href=""><span class="glyphicon glyphicon-list"></span> Topics</a></li>
                </ul>
            -->
                <div>
					<form class="navbar-form navbar-right" method="POST"role="search" action="login.php">
					<div class="form-group">
					<input type="text" class="form-control" name="user"placeholder="Username">
					<input type="password" class="form-control" name="pass"placeholder="Password">
					</div>
					<button type="submit" class="btn btn-success" name="login">Login</button>
          <a href="recoverpassword.php">Forgot Password</a>
					</form>

				</div>
                
            </div>
            <!-- /.navbar-collapse -->
        </div>

        <!-- /.container-fluid -->
    </nav>
			<div class="container" style="margin:5% auto;">
				<div class="col-sm-5 col-md-3">
					


<img src="images/quote.jpg" style=" opacity: 0.6; border-radius: 30px; background-image: inherit;">


									</div>
				 <div class="col-sm-5 col-md-4 pull-right">
                   <div class="row">
                   
						<form method="POST" class="form-signin" action="signup.php">
								<h3 class="text-center" style="color: white; ">SIGNUP FORM</h3>
          <input id="email" name="email" class="form-control" placeholder="example@domain.com" required="" type="email" value="<?php if(isset($_POST['signup'])) { echo $_POST['email']; } ?>"> 
          <input id="username" class="form-control" name="username" placeholder="username" requiredtabindex="2" type="text" value="<?php if(isset($_POST['signup'])) { echo $_POST['username']; } ?>"> 
          <input type="password" placeholder="Password" name="password" class="form-control" required>
          <input type="password" placeholder="Re-enter Password" name="repassword" class="form-control" required> <select class="form-control" name="role">
            <option>I am a</option>
            <option value="teacher">Teacher</option>
            <option value="student">Student</option>
            </select>
            <select class="form-control" name="course">
            <option>I Study/Teach</option>
            <option value="Computer Science">Computer Sc Engineering</option>
            <option value="Electrical">Electrical Engineering</option>
            <option value="Mechanical">Mechanical Engineering</option>
            </select>
							<select class="form-control" name="gender"required>
								<option>Gender</option>
								<option value="Male">Male</option>
								<option value="Female">Female</option>
							</select>
							<button type="submit" class="btn btn-success" name="signup">Sign up</button>
							

							
              
						</form>
				</div>
			</div>
		</div>

    





<style>
.footer {
   position:fixed;
   left: 0;
   bottom: 0.5px;
   width: 100%;
   background-color: #333;
   color: white;
   height: 45px;
   text-align: center;
   opacity: 0.8;

}

</style>
<div class="footer">
  <p>Copyright 2018 BE.CMP EEC All right Reserved </p>
</div>





</body>
</html>